#!/user/bin/env python
# -*- coding:utf-8 -*-

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch.utils as utils
import torchvision
import torchvision.transforms as transforms
from torch.utils.tensorboard import SummaryWriter
import time


# (M-F+2P)/S+1
class LeNet(nn.Module):
    def __init__(self):
        super(LeNet, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(1, 6, 5, stride=1, padding=2),
            nn.ReLU(True),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(6, 16, 5, stride=1, padding=0),
            nn.ReLU(True),
            nn.MaxPool2d(2, 2))

        self.fc = nn.Sequential(
            nn.Linear(400, 120),
            nn.Linear(120, 84),
            nn.Dropout(0.5),
            nn.Linear(84, 10))

    def forward(self, x):
        out = self.conv(x)
        out = out.view(out.size(0), -1)
        out = self.fc(out)
        return out


class Model(torch.nn.Module):

    def __init__(self):
        super(Model, self).__init__()
        self.conv1 = torch.nn.Sequential(torch.nn.Conv2d(1, 16, kernel_size=3, stride=1, padding=1),
                                         nn.BatchNorm2d(16),
                                         torch.nn.ReLU(),
                                         torch.nn.Conv2d(16, 32, kernel_size=3, stride=1, padding=1),
                                         nn.BatchNorm2d(32),
                                         torch.nn.ReLU(),
                                         torch.nn.MaxPool2d(stride=2, kernel_size=2),
                                         torch.nn.Conv2d(32, 64, kernel_size=3, stride=1, padding=1),
                                         nn.BatchNorm2d(64),
                                         torch.nn.ReLU(),
                                         torch.nn.Conv2d(64, 128, kernel_size=3, stride=1, padding=1),
                                         nn.BatchNorm2d(128),
                                         torch.nn.ReLU(),
                                         torch.nn.MaxPool2d(stride=2, kernel_size=2)
                                         )
        self.dense = torch.nn.Sequential(torch.nn.Linear(7 * 7 * 128, 1024),
                                         torch.nn.ReLU(),
                                         torch.nn.Dropout(p=0.5),
                                         torch.nn.Linear(1024, 10))

    def forward(self, x):
        x = self.conv1(x)
        x = x.view(-1, 7 * 7 * 128)
        x = self.dense(x)
        return x


# 用于ResNet18和34的残差块，用的是2个3x3的卷积
class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_planes, planes, stride=1):
        super(BasicBlock, self).__init__()
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=3,
                               stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(planes)
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3,
                               stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(planes)
        self.shortcut = nn.Sequential()
        # 经过处理后的x要与x的维度相同(尺寸和深度)
        # 如果不相同，需要添加卷积+BN来变换为同一维度
        if stride != 1 or in_planes != self.expansion * planes:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_planes, self.expansion * planes,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(self.expansion * planes)
            )

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out += self.shortcut(x)
        out = F.relu(out)
        return out


class ResNet(nn.Module):
    def __init__(self, block, num_blocks, num_classes=10):
        super(ResNet, self).__init__()
        self.in_planes = 64

        self.conv1 = nn.Conv2d(1, 64, kernel_size=3,
                               stride=1, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)

        self.layer1 = self._make_layer(block, 64, num_blocks[0], stride=1)
        self.layer2 = self._make_layer(block, 128, num_blocks[1], stride=2)
        self.layer3 = self._make_layer(block, 256, num_blocks[2], stride=2)
        self.layer4 = self._make_layer(block, 512, num_blocks[3], stride=2)
        self.linear = nn.Linear(512 * block.expansion, num_classes)

    def _make_layer(self, block, planes, num_blocks, stride):
        strides = [stride] + [1] * (num_blocks - 1)
        layers = []
        for stride in strides:
            layers.append(block(self.in_planes, planes, stride))
            self.in_planes = planes * block.expansion
        return nn.Sequential(*layers)

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.layer1(out)
        out = self.layer2(out)
        out = self.layer3(out)
        out = self.layer4(out)
        out = F.avg_pool2d(out, 4)
        out = out.view(out.size(0), -1)
        out = self.linear(out)
        return out


def ResNet18():
    return ResNet(BasicBlock, [2, 2, 2, 2])


def load_data():
    train_data = torchvision.datasets.MNIST(
        root='./data',
        train=True,
        transform=transforms.ToTensor(),
        download=True
    )
    test_data = torchvision.datasets.MNIST(
        root="./data",
        train=False,
        transform=transforms.ToTensor(),
        download=True
    )
    train_data, val_data = torch.utils.data.random_split(train_data, [50000, 10000])
    train_loader = utils.data.DataLoader(
        dataset=train_data,
        batch_size=64,
        shuffle=True
    )
    val_loader = utils.data.DataLoader(
        dataset=val_data,
        batch_size=64,
        shuffle=True
    )
    test_loader = utils.data.DataLoader(
        dataset=test_data,
        batch_size=64,
        shuffle=False
    )
    return train_loader, val_loader, test_loader


def train(net, train_loader, val_loader, test_loader, PATH, writer=None):
    # get some random training images
    # dataiter = iter(train_loader)
    # images, labels = dataiter.next()
    # writer.add_graph(net, images)
    # writer.close()

    criterion = nn.CrossEntropyLoss()
    # optimizer = optim.SGD(net.parameters(), lr=0.001, momentum=0.9)
    optimizer = optim.Adam(net.parameters())
    starttime = time.time()
    for epoch in range(10):

        running_loss = 0.0
        for i, data in enumerate(train_loader, 0):
            inputs, labels = data
            optimizer.zero_grad()
            outputs = net(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
            if i % 20 == 19:  # print every 20 mini-batches
                print('[%d, %5d] loss: %.3f' %
                      (epoch + 1, i + 1, running_loss / 20))
                # writer.add_scalar('training loss',
                #                   running_loss / 20,
                #                   epoch * len(train_loader) + i)
                running_loss = 0.0
        correct = 0
        total = 0
        with torch.no_grad():
            loss = 0
            t = 0
            for data in val_loader:
                images, labels = data
                outputs = net(images)
                loss += criterion(outputs, labels)
                _, predicted = torch.max(outputs.data, 1)
                total += labels.size(0)
                t += 1
                correct += (predicted == labels).sum().item()
            writer.add_scalar('validation_loss',
                              loss/t,
                              epoch)
            # writer.add_scalar('accuracy',
            #                   100 * correct / total,
            #                   epoch)
        torch.save(net.state_dict(), PATH)

        print('Epoch %d Accuracy of the network on the test images: %f %%' % (epoch + 1,
                                                                              100 * correct / total))

    print('Finished Training')
    endtime = time.time()
    print("train time", endtime - starttime)
    torch.save(net.state_dict(), PATH)


def test(net, test_loader):
    correct = 0
    total = 0
    c = 0
    perform = []
    with torch.no_grad():
        for data in test_loader:
            images, labels = data
            net.eval()
            outputs = net(images)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            for i in range(10):
                TP = ((predicted == i) & (labels == i)).sum().item()
                FP = ((predicted == i) & (labels != i)).sum().item()
                FN = ((predicted != i) & (labels == i)).sum().item()
                if len(perform) <= i:
                    perform.append([TP, FP, FN])
                else:
                    perform[i][0] += TP
                    perform[i][1] += FP
                    perform[i][2] += FN
    print('Accuracy of the network on the 10000 test images: %f %%' % (
            100 * correct / total))
    prec = 0
    recall = 0
    TP = 0
    FP = 0
    FN = 0
    for i in range(10):
        prec += perform[i][0] / (perform[i][1] + perform[i][0])
        recall += perform[i][0] / (perform[i][2] + perform[i][0])
        TP += perform[i][0]
        FP += perform[i][1]
        FN += perform[i][2]
    macro_prec = prec / 10
    macro_recall = recall / 10
    macro_F1 = 2 * macro_recall * macro_prec / (macro_recall + macro_prec)
    micro_prec = TP / (FP + TP)
    micro_recall = TP / (FN + TP)
    micro_F1 = 2 * micro_recall * micro_prec / (micro_recall + micro_prec)
    print(
        "macro_prec {}\nmacro_recall {}\nmacro_F1 {}\nmicro_prec {}\nmicro_recall {}\nmicro_F1 {}\n".format(macro_prec,
                                                                                                            macro_recall,
                                                                                                            macro_F1,
                                                                                                            micro_prec,
                                                                                                            micro_recall,
                                                                                                            micro_F1))


if __name__ == "__main__":
    #net = LeNet()
    net = Model()
    #net = ResNet18()
    print(net)

    PATH = 'CNN.pth'
    train_loader, val_loader, test_loader = load_data()
    #writer = SummaryWriter("runs/CNN")
    #train(net, train_loader, val_loader, test_loader, PATH)
    net.load_state_dict(torch.load(PATH))
    test(net, test_loader)
