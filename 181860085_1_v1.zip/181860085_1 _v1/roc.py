#!/user/bin/env python
# -*- coding:utf-8 -*-

from sklearn.metrics import roc_curve, auc
import numpy as np
import matplotlib.pyplot as plt


def draw(fpr, tpr,auc):
    plt.figure()
    lw = 2
    plt.plot(fpr, tpr, color='darkorange',
             lw=lw, label='ROC curve (area = %0.2f)' % auc)
    plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic')
    plt.legend(loc="lower right")
    plt.show()


y = np.array([1, 0, 1, 1, 1, 0, 0, 0])
scores1 = np.array([0.6, 0.31, 0.58, 0.22, 0.4, 0.51, 0.2, 0.33])
scores2 = np.array([0.04, 0.1, 0.68, 0.24, 0.32, 0.12, 0.8, 0.51])

fpr1, tpr1, thresholds1 = roc_curve(y, scores1, pos_label=1)
print(fpr1, tpr1, thresholds1)
auc1 = auc(fpr1,tpr1)
draw(fpr1,tpr1,auc1)

fpr2, tpr2, thresholds2= roc_curve(y, scores2, pos_label=1)
print(fpr2, tpr2, thresholds2)
auc2 = auc(fpr2,tpr2)
draw(fpr2,tpr2,auc2)