#!/user/bin/env python
# -*- coding:utf-8 -*-

import pandas as pd
import numpy as np
import time
from sklearn import preprocessing


def sigmoid(x, beta):
    return 1 / (1 + np.exp(-np.dot(x, beta)))


def f(x, beta, y):
    return 1 / (x.shape[0]) * np.dot(x.T, sigmoid(x, beta) - y)


def f_(x, beta, y):
    n = x.shape[0]
    pred = sigmoid(x, beta).reshape(n)
    return 1 / (n) * np.dot(np.dot(np.dot(x.T, np.diag(pred)), np.diag(1 - pred)), x)


def newton(x, beta, y):
    l_1 = f(x, beta, y)
    l_2 = f_(x, beta, y)
    iter = 0
    while np.mean(abs(l_1)) > 1e-6:
        beta = beta - np.dot(np.linalg.inv(l_2), l_1)
        l_1 = f(x, beta, y)
        l_2 = f_(x, beta, y)
        iter = iter + 1
    print('iter:', iter)
    return beta


def gradient_descent(x, y, alpha):
    beta = np.zeros((x.shape[1], 1))
    l_1 = f(x, beta, y)
    iter = 0
    while np.mean(abs(l_1)) > 1e-6:
        beta = beta - alpha * l_1
        l_1 = f(x, beta, y)
        iter = iter + 1
    print('iter:', iter)
    return beta


class Logistic:
    def __init__(self, optim, label, alpha=0.1):
        self.optim = optim
        self.label = label
        if self.optim == 'Gradient':
            self.alpha = alpha

    def load(self, beta):
        self.beta = beta

    def train(self, x, y):
        self.beta = np.zeros((x.shape[1], 1))
        y = (y == self.label)
        if self.optim == 'Newton':
            self.beta = newton(x, self.beta, y)
        else:
            self.beta = gradient_descent(x, y, self.alpha)
        return self.beta

    def evaluate(self, x, y):
        y = (y == self.label)
        y_pred = (sigmoid(x, self.beta) > 0.5).reshape(-1, 1).astype(np.int)
        acc = np.sum(y_pred == y) / len(y_pred)
        TP = np.sum((y == 1) & (y_pred == 1))
        FN = np.sum((y == 1) & (y_pred == 0))
        FP = np.sum((y == 0) & (y_pred == 1))
        prec = 0
        if (TP + FP) != 0:
            prec = TP / (TP + FP)
        recall = 0
        if (TP + FN) != 0:
            recall = TP / (TP + FN)
        F1 = 0
        # if (prec + recall) != 0:
        #     F1 = 2 * prec * recall / (prec + recall)
        return [acc, prec, recall, TP, FP, FN]


class Multi_Classifier:
    def __init__(self, category, alg, alpha=0.1):
        self.category = category
        self.alg = alg
        self.classifier = []
        for i in range(category):
            if alg == 'Newton':
                self.classifier.append(Logistic(alg, i + 1))
            else:
                self.alpha = alpha
                self.classifier.append(Logistic(alg, i + 1, alpha))
        self.beta = None
        self.perform = []

    def load(self, fname):
        self.beta = np.load(fname)
        for i in range(self.category):
            self.classifier[i].load(self.beta[:, i])

    def train(self, x, y):
        for i in range(self.category):
            if self.beta is None:
                self.beta = self.classifier[i].train(x, y)
            else:
                self.beta = np.hstack((self.beta, self.classifier[i].train(x, y)))
            print(i)
            self.perform.append(self.classifier[i].evaluate(x, y))
        np.save('para_' + self.alg + '.npy', self.beta)
        return self.beta, self.perform

    def evaluate(self, x, y):
        self.perform = []
        for i in range(self.category):
            self.perform.append(self.classifier[i].evaluate(x, y))
        pred = sigmoid(x, self.beta)
        y_pred = (np.argmax(pred, axis=1) + 1).reshape(-1, 1)
        acc = np.sum(y_pred == y) / len(y_pred)
        prec = 0
        recall = 0
        TP = 0
        FP = 0
        FN = 0
        for i in range(len(self.perform)):
            prec = prec + self.perform[i][1]
            recall = recall + self.perform[i][2]
            TP = TP + self.perform[i][3]
            FP = FP + self.perform[i][4]
            FN = FN + self.perform[i][5]
        macro_prec = prec / self.category
        macro_recall = recall / self.category
        macro_F1 = 2 * macro_prec * macro_recall / (macro_prec + macro_recall)
        micro_prec = TP / (TP + FP)
        micro_recall = TP / (TP + FN)
        micro_F1 = 2 * micro_prec * micro_recall / (micro_prec + micro_recall)

        return [acc, micro_prec, micro_recall, micro_F1, macro_prec, macro_recall, macro_F1]


if __name__ == "__main__":
    # 读取数据
    train = pd.read_csv('data/train_set.csv')
    x_train = train.iloc[:, 0:16]
    y_train = train.loc[:, 'class']

    test = pd.read_csv('data/test_set.csv')
    x_test = test.iloc[:, 0:16]
    y_test = test.loc[:, 'class']

    # 缺失值处理
    train.dropna(inplace=True)
    test.dropna(inplace=True)

    # 标准化
    mean = x_train.mean()
    std = x_train.std()
    x_train = (x_train - mean) / std
    x_test = (x_test - mean) / std

    x_train['constant'] = 1
    x_test['constant'] = 1
    x_train = x_train.to_numpy()
    y_train = y_train.to_numpy().reshape(-1, 1)
    x_test = x_test.to_numpy()
    y_test = y_test.to_numpy().reshape(-1, 1)

    print("牛顿法")
    multi_classifier = Multi_Classifier(26, 'Newton')
    # start = time.time()
    # beta, micro_acc = multi_classifier.train(x_train, y_train)
    # end = time.time()
    # print("用时:", end - start)
    multi_classifier.load('para_Newton.npy')
    perform_metric = multi_classifier.evaluate(x_test, y_test)
    print("accurcy,micro_precision,micro_recall,micro_F1,macro_precision,macro_recall,macro_F1")
    print(perform_metric)

    print("梯度下降法")
    multi_classifier2 = Multi_Classifier(26, 'Gradient', 0.1)
    # start = time.time()
    # beta2, micro_acc2 = multi_classifier2.train(x_train, y_train)
    # end = time.time()
    # print("用时", end - start)
    multi_classifier2.load('para_Gradient.npy')
    perform_metric2 = multi_classifier2.evaluate(x_test, y_test)
    print("accurcy,micro_precision,micro_recall,micro_F1,macro_precision,macro_recall,macro_F1")
    print(perform_metric2)
