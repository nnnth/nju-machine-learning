#!/user/bin/env python
# -*- coding:utf-8 -*-

import pandas as pd
import numpy as np
from sklearn import tree
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import auc, roc_curve
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler, LabelEncoder
import matplotlib.pyplot as plt


def draw(fpr, tpr, auc):
    plt.figure()
    lw = 2
    plt.plot(fpr, tpr, color='darkorange',
             lw=lw, label='ROC curve (area = %0.2f)' % auc)
    plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic')
    plt.legend(loc="lower right")
    plt.show()


def load_data(file, encoder=None):
    data = pd.read_csv(file, header=None, na_values=" ?")
    data = data.dropna()
    y = LabelEncoder().fit_transform(data.iloc[:, -1])
    # 标签转为-1，1
    y = 2 * y - 1
    data.drop(14, axis=1, inplace=True)
    df_categorical = data.select_dtypes('object')
    df_numerical = data.select_dtypes("number")
    if not encoder:
        encoder = (OneHotEncoder(handle_unknown='ignore'), MinMaxScaler())
        encoder[0].fit(df_categorical)
        encoder[1].fit(df_numerical)
    np_categorical = encoder[0].transform(df_categorical).toarray()
    np_numerical = encoder[1].transform(df_numerical)
    X = np.hstack((np_numerical, np_categorical))
    return X, y, encoder


def train(X, y, iter):
    trees = []
    m = len(X)
    for i in range(iter):
        print(i)
        # bootstrap
        index = np.random.randint(0, m, size=m)
        samplex = X[index, :]
        # 取sqrt(n_features)个属性
        clf = tree.DecisionTreeClassifier(max_depth=20, max_features='auto')
        clf.fit(samplex, y[index])
        trees.append(clf)
    return trees


def test(X, y, trees, plot=False):
    pred = [0] * len(y)
    for i in range(len(trees)):
        pred += trees[i].predict(X)
    for i in range(len(pred)):
        if pred[i] > 0:
            pred[i] = 1
        elif pred[i] < 0:
            pred[i] = -1
        else:
            rand = np.random.randint(0, 2)
            # 随机数为0则为-1，为1则为1
            pred[i] = 2 * rand - 1
    error = np.sum(pred != y) / len(y)
    fpr, tpr, thresholds = roc_curve(y, pred, pos_label=1)
    auc_score = auc(fpr, tpr)
    if plot:
        draw(fpr, tpr, auc_score)
    print("error", error)
    print("auc", auc_score)
    return auc_score


def fold5(X, y,iter):
    kf = StratifiedKFold(n_splits=5)
    allauc = []
    for train_index, test_index in kf.split(X, y):
        train_x,train_y = X[train_index],y[train_index]
        test_x, test_y = X[test_index], y[test_index]
        trees = train(train_x,train_y,iter)
        temp = test(test_x, test_y, trees)
        allauc.append(temp)
    mean_auc = np.mean(allauc)
    print("mean_auc", mean_auc)
    return mean_auc


def search(X, y, iters, legend=()):
    best = None
    bestauc = 0
    bestnum = 0
    res = []
    for iter in iters:
        model = train(X, y, iter)
        auc_score = fold5(X, y, iter)
        if auc_score > bestauc:
            bestauc = auc_score
            best = model
            bestnum = iter
        res.append(auc_score)
    plt.plot(iters, res)
    plt.legend(legend)
    plt.show()
    print(bestnum, bestauc)
    return best


if __name__ == "__main__":
    X, y, enc = load_data("adult.data")
    best = train(X, y, 60)
    X_test, y_test, _ = load_data("adult.test", encoder=enc)
    test(X_test,y_test,best,plot=True)
