#!/user/bin/env python
# -*- coding:utf-8 -*-

import pandas as pd
import numpy as np
from sklearn import tree
from sklearn.model_selection import KFold, StratifiedKFold
from sklearn.metrics import auc, roc_curve
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler, LabelEncoder
import matplotlib.pyplot as plt


def draw(fpr, tpr, auc):
    plt.figure()
    lw = 2
    plt.plot(fpr, tpr, color='darkorange',
             lw=lw, label='ROC curve (area = %0.2f)' % auc)
    plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic')
    plt.legend(loc="lower right")
    plt.show()


def train(X, y, iter, max_depth=5):
    trees = []
    allalpha = []
    m = 1 / len(X)
    weight = np.ones(len(X)) * m
    for i in range(iter):
        print(i)
        clf = tree.DecisionTreeClassifier(max_depth=max_depth,random_state=0)
        clf.fit(X, y, sample_weight=weight)
        y_pred = clf.predict(X)
        error = np.dot((y_pred != y), weight)
        if error > 0.5:
            print(i)
            break
        alpha = 0.5 * np.log((1 - error) / error)
        trees.append(clf)
        allalpha.append(alpha)
        weight_new = weight * np.exp(-alpha * y_pred * y)
        weight_new = weight_new / np.sum(weight_new)
        weight = weight_new
    return trees, allalpha


def test(X, y, trees, allalpha, plot=False):
    pred = np.zeros(len(X))
    for i in range(len(trees)):
        pred += allalpha[i] * trees[i].predict(X)
    y_pred = [1 if pred[i] > 0 else -1 for i in range(len(y))]
    error = np.sum(y_pred != y) / len(y)
    fpr, tpr, thresholds = roc_curve(y, y_pred, pos_label=1)
    auc_score = auc(fpr, tpr)
    if plot:
        draw(fpr, tpr, auc_score)
    print("error", error)
    print("auc", auc_score)
    return auc_score


def fold5(X, y,iter,depth):
    kf = StratifiedKFold(n_splits=5)
    allauc = []
    for train_index, test_index in kf.split(X, y):
        train_x,train_y = X[train_index],y[train_index]
        test_x, test_y = X[test_index], y[test_index]
        trees,alpha = train(train_x,train_y,iter,depth)
        temp = test(test_x, test_y, trees, alpha)
        allauc.append(temp)
    mean_auc = np.mean(allauc)
    print("mean_auc", mean_auc)
    return mean_auc


def load_data(file, encoder=None):
    data = pd.read_csv(file, header=None, na_values=" ?")
    data = data.dropna()
    y = LabelEncoder().fit_transform(data.iloc[:, -1])
    # 标签转为-1，1
    y = 2 * y - 1
    data.drop(14, axis=1, inplace=True)
    df_categorical = data.select_dtypes('object')
    df_numerical = data.select_dtypes("number")
    if not encoder:
        encoder = (OneHotEncoder(handle_unknown='ignore'), MinMaxScaler())
        encoder[0].fit(df_categorical)
        encoder[1].fit(df_numerical)
    np_categorical = encoder[0].transform(df_categorical).toarray()
    np_numerical = encoder[1].transform(df_numerical)
    X = np.hstack((np_numerical, np_categorical))
    return X, y, encoder


def search(X, y, iters, depths, legend=None):
    best = None
    bestalpha = None
    bestauc = 0
    bestnum = 0
    bestdepth = 0
    allres = []
    for depth in depths:
        res = []
        for iter in iters:
            model, alpha = train(X, y, iter, depth)
            auc_score = fold5(X, y, iter,depth)
            if auc_score > bestauc:
                bestdepth = depth
                bestauc = auc_score
                best = model
                bestnum = iter
                bestalpha = alpha
            res.append(auc_score)
        allres.append(res)
    for i in allres:
        plt.plot(iters, i)
    plt.legend(legend)
    plt.show()
    print(bestnum, bestdepth, bestauc)
    return best, bestalpha


if __name__ == "__main__":
    X, y, enc = load_data("adult.data")
    best, bestalpha = train(X, y, 150, 4)
    X_test, y_test, _ = load_data("adult.test", encoder=enc)
    test(X_test, y_test, best, bestalpha, plot=True)


